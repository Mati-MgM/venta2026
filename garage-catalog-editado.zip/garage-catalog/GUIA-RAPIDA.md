# 🚀 GUÍA RÁPIDA - CÓMO AGREGAR UN PRODUCTO NUEVO

## Paso a Paso

### 1. Abre el archivo de productos
Archivo: `lib/products-config.ts`

### 2. Copia este template
```typescript
{
  id: "XX",                           // ⚠️ Usa el siguiente número disponible
  title: "Nombre del producto",       // El título que verán tus clientes
  price: 100,                         // Solo el número (sin $)
  category: "Muebles",                // Elige: Muebles, Electrónica, Ropa, Varios
  status: "Disponible",               // Disponible o Vendido
  images: ["/images/foto.jpg"],       // Ruta de tu imagen
  description: "Descripción breve",   // Unas pocas líneas
  condition: "Estado del artículo"    // Condición, detalles, etc.
},
```

### 3. Pégalo al final de la lista de productos
Justo antes del último corchete `]` en el archivo `products-config.ts`

### 4. ¡No olvides la coma!
Cada producto debe terminar con una coma, excepto el último.

---

## ✅ Ejemplo Real

Digamos que quieres agregar una **laptop**:

```typescript
{
  id: "34",
  title: "Laptop HP 15 pulgadas",
  price: 350,
  category: "Electrónica",
  status: "Disponible",
  images: ["/images/laptop.jpg", "/images/laptop-teclado.jpg"],
  description: "Laptop HP con procesador i5, 8GB RAM, 256GB SSD. Ideal para trabajo y estudio.",
  condition: "Excelente estado, batería nueva instalada hace 3 meses. Incluye cargador original."
},
```

---

## 📸 Cómo usar múltiples imágenes

Si tienes varias fotos del mismo producto:

```typescript
images: [
  "/images/laptop-frente.jpg",     // Foto principal
  "/images/laptop-teclado.jpg",    // Detalle del teclado
  "/images/laptop-puertos.jpg"     // Puertos laterales
]
```

La primera imagen es la que aparece en la tarjeta principal.

---

## 🔄 Cómo marcar un producto como VENDIDO

Solo cambia el `status`:

```typescript
status: "Vendido"  // Antes era "Disponible"
```

---

## 🗑️ Cómo eliminar un producto

Simplemente borra TODO el bloque completo del producto (incluyendo las llaves `{ }`).

**Antes:**
```typescript
{
  id: "5",
  title: "Mesa de centro",
  ...
},
{
  id: "6",  // ← Este se va a eliminar
  title: "Mesa de noche",
  price: 45,
  ...
},
{
  id: "7",
  title: "Cama Queen",
  ...
}
```

**Después:**
```typescript
{
  id: "5",
  title: "Mesa de centro",
  ...
},
{
  id: "7",
  title: "Cama Queen",
  ...
}
```

---

## 💡 Tips Pro

### Nombres de Imágenes Descriptivos
✅ BIEN: `sofa-gris-3plazas.jpg`  
❌ MAL: `IMG_1234.jpg`

### Optimiza tus Imágenes
- Tamaño recomendado: 800x600 píxeles
- Peso máximo: 500KB por imagen
- Usa herramientas como [TinyPNG](https://tinypng.com) para comprimir

### Descripciones Efectivas
Incluye:
- ✅ Características principales
- ✅ Dimensiones si aplica
- ✅ Marca/modelo
- ✅ Qué incluye

Evita:
- ❌ Información personal
- ❌ Textos muy largos
- ❌ Mayúsculas sostenidas

---

## 🎯 Checklist antes de guardar

- [ ] El `id` es único (no repetido)
- [ ] Agregaste la coma al final `,`
- [ ] La imagen existe en `/public/images/`
- [ ] La categoría es una de las 4 válidas
- [ ] El precio es solo número
- [ ] Revisaste la ortografía

---

## 🆘 Si algo sale mal

### "La página no carga"
1. Revisa que cada producto tenga coma `,` al final
2. Verifica que todos los `{` tengan su `}`
3. Asegúrate que guardaste el archivo

### "No aparece mi imagen"
1. La imagen debe estar en `public/images/`
2. El nombre debe coincidir EXACTAMENTE
3. Usa minúsculas en los nombres de archivo

---

¡Listo! Con esto ya puedes agregar productos fácilmente. 🎉
