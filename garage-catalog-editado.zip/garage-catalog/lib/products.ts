export type Category = "Muebles" | "Electrónica" | "Ropa" | "Varios" |
export type Status = "Disponible" | "Vendido"

export interface Product {
  id: string
  title: string
  price: number
  category: Category
  status: Status
  images: string[]
  description: string
  condition: string
}

export const products: Product[] = [
  // MUEBLES
  {
    id: "1",
    title: "Sofá de 3 plazas",
    price: 150,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/sofa.jpg", "/images/sofa-2.jpg", "/images/sofa-3.jpg"],
    description: "Sofá en excelente estado, color gris oscuro. Perfecto para sala de estar.",
    condition: "Muy buen estado, sin manchas ni roturas. Solo 2 años de uso."
  },
  {
    id: "2",
    title: "Mesa de comedor",
    price: 120,
    category: "Muebles",
    status: "Vendido",
    images: ["/images/table.jpg"],
    description: "Mesa de madera para 6 personas con acabado natural.",
    condition: "Algunas marcas de uso normal, pero muy resistente."
  },
  {
    id: "3",
    title: "Silla de oficina ergonómica",
    price: 75,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/chair.jpg", "/images/chair-side.jpg", "/images/chair-back.jpg"],
    description: "Silla ergonómica con soporte lumbar y reposabrazos ajustables.",
    condition: "Buen estado, muy cómoda para trabajar desde casa. Vista frontal, lateral y trasera disponibles."
  },
  {
    id: "4",
    title: "Estantería de madera",
    price: 65,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/bookshelf.jpg"],
    description: "Estantería de 5 niveles, ideal para libros o decoración.",
    condition: "Muy buen estado, fácil de armar."
  },
  {
    id: "5",
    title: "Mesa de centro con vidrio",
    price: 85,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/coffee-table.jpg", "/images/coffee-table-2.jpg"],
    description: "Mesa de centro moderna con base de madera y tope de vidrio templado.",
    condition: "Excelente estado, sin rayones en el vidrio."
  },
  {
    id: "6",
    title: "Mesa de noche",
    price: 45,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/nightstand.jpg"],
    description: "Mesa de noche con dos cajones amplios, estilo moderno.",
    condition: "Muy buen estado, cajones funcionan perfectamente."
  },
  {
    id: "7",
    title: "Cama Queen con cabecera",
    price: 220,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/bed.jpg", "/images/bed-2.jpg"],
    description: "Estructura de cama Queen size con cabecera de madera maciza.",
    condition: "Excelente estado, muy resistente. No incluye colchón."
  },
  {
    id: "8",
    title: "Escritorio de trabajo",
    price: 95,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/desk.jpg", "/images/desk-2.jpg"],
    description: "Escritorio minimalista con cajón y espacio para cables.",
    condition: "Como nuevo, ideal para home office."
  },
  {
    id: "9",
    title: "Espejo de cuerpo completo",
    price: 55,
    category: "Muebles",
    status: "Disponible",
    images: ["/images/mirror.jpg"],
    description: "Espejo de pie con marco de madera, altura 1.70m.",
    condition: "Perfecto estado, sin manchas ni rayones."
  },

  // ELECTRÓNICA
  {
    id: "10",
    title: "Televisor 50\" 4K",
    price: 280,
    category: "Electrónica",
    status: "Disponible",
    images: ["/images/tv.jpg", "/images/tv-2.jpg"],
    description: "Smart TV Samsung con resolución 4K y HDR.",
    condition: "Funciona perfectamente. Incluye control remoto y base."
  },
  {
    id: "11",
    title: "PlayStation 4 Slim",
    price: 180,
    category: "Electrónica",
    status: "Disponible",
    images: ["/images/ps4.jpg", "/images/ps4-2.jpg", "/images/ps4-3.jpg"],
    description: "PS4 Slim 1TB con dos controles y 5 juegos incluidos.",
    condition: "Funciona perfectamente. Poco uso. Fotos de consola, controles y conexiones."
  },
  {
    id: "12",
    title: "Auriculares Bluetooth",
    price: 40,
    category: "Electrónica",
    status: "Disponible",
    images: ["/images/headphones.jpg"],
    description: "Auriculares inalámbricos con cancelación de ruido activa.",
    condition: "Como nuevos, incluye estuche de carga y cable."
  },
  {
    id: "13",
    title: "Tablet 10 pulgadas",
    price: 150,
    category: "Electrónica",
    status: "Disponible",
    images: ["/images/tablet.jpg", "/images/tablet-2.jpg"],
    description: "Tablet con pantalla 10 pulgadas, incluye stylus.",
    condition: "Buen estado, batería dura todo el día."
  },
  {
    id: "14",
    title: "Cámara DSLR Canon",
    price: 350,
    category: "Electrónica",
    status: "Disponible",
    images: ["/images/camera.jpg", "/images/camera-2.jpg", "/images/camera-3.jpg"],
    description: "Cámara profesional con lente 18-55mm incluido.",
    condition: "Excelente estado, fotos de frente, arriba y atrás. Incluye correa y bolso."
  },
  {
    id: "15",
    title: "Parlante Bluetooth portátil",
    price: 35,
    category: "Electrónica",
    status: "Disponible",
    images: ["/images/speaker.jpg"],
    description: "Parlante portátil resistente al agua con 12 horas de batería.",
    condition: "Funciona perfectamente, sonido potente."
  },

  // ROPA
  {
    id: "16",
    title: "Chaqueta de cuero",
    price: 45,
    category: "Ropa",
    status: "Disponible",
    images: ["/images/jacket.jpg", "/images/jacket-2.jpg"],
    description: "Chaqueta de cuero genuino talla M, color negro.",
    condition: "Como nueva, usada solo un par de veces. Detalle de cierre incluido."
  },
  {
    id: "17",
    title: "Vestido de fiesta",
    price: 30,
    category: "Ropa",
    status: "Vendido",
    images: ["/images/dress.jpg"],
    description: "Vestido largo color azul marino, talla S.",
    condition: "Usado una vez para un evento especial."
  },
  {
    id: "18",
    title: "Zapatillas deportivas",
    price: 25,
    category: "Ropa",
    status: "Disponible",
    images: ["/images/sneakers.jpg"],
    description: "Zapatillas deportivas talla 42, color rojo.",
    condition: "Poco uso, suela en buen estado."
  },
  {
    id: "19",
    title: "Abrigo de invierno",
    price: 60,
    category: "Ropa",
    status: "Disponible",
    images: ["/images/coat.jpg"],
    description: "Parka azul marino talla L, muy abrigada con capucha.",
    condition: "Excelente estado, sin roturas ni manchas."
  },
  {
    id: "20",
    title: "Jeans azul clásico",
    price: 20,
    category: "Ropa",
    status: "Disponible",
    images: ["/images/jeans.jpg"],
    description: "Jeans de mezclilla azul talla 32, corte recto.",
    condition: "Buen estado, color ligeramente desgastado (estilo vintage)."
  },
  {
    id: "21",
    title: "Mochila para laptop",
    price: 35,
    category: "Ropa",
    status: "Disponible",
    images: ["/images/backpack.jpg", "/images/backpack-2.jpg"],
    description: "Mochila con compartimento acolchado para laptop 15 pulgadas.",
    condition: "Como nueva, múltiples bolsillos. Fotos exterior e interior."
  },
  {
    id: "22",
    title: "Botas de cuero",
    price: 40,
    category: "Ropa",
    status: "Disponible",
    images: ["/images/boots.jpg"],
    description: "Botas de cuero marrón talla 40, estilo casual.",
    condition: "Buen estado, suela con algo de uso pero muy cómodas."
  },
  {
    id: "23",
    title: "Reloj clásico",
    price: 55,
    category: "Ropa",
    status: "Vendido",
    images: ["/images/watch.jpg"],
    description: "Reloj de pulsera con correa de cuero, esfera blanca.",
    condition: "Funciona perfectamente, correa en buen estado."
  },

  // VARIOS
  {
    id: "24",
    title: "Lámpara de pie LED",
    price: 35,
    category: "Varios",
    status: "Disponible",
    images: ["/images/lamp.jpg"],
    description: "Lámpara de pie moderna con luz LED regulable.",
    condition: "Perfectas condiciones, incluye bombilla LED."
  },
  {
    id: "25",
    title: "Set de ollas de cocina",
    price: 55,
    category: "Varios",
    status: "Disponible",
    images: ["/images/pots.jpg"],
    description: "Juego de 5 ollas de acero inoxidable con tapas de vidrio.",
    condition: "Excelente estado, usadas pocas veces."
  },
  {
    id: "26",
    title: "Bicicleta de montaña",
    price: 180,
    category: "Varios",
    status: "Disponible",
    images: ["/images/bicycle.jpg", "/images/bicycle-2.jpg"],
    description: "Bicicleta MTB rodado 26, 21 velocidades.",
    condition: "Muy buen estado, frenos y cambios funcionan perfectamente. Detalle de engranajes."
  },
  {
    id: "27",
    title: "Licuadora de alta potencia",
    price: 45,
    category: "Varios",
    status: "Disponible",
    images: ["/images/blender.jpg"],
    description: "Licuadora con vaso de vidrio y 5 velocidades.",
    condition: "Funciona perfectamente, muy potente para smoothies."
  },
  {
    id: "28",
    title: "Guitarra acústica",
    price: 120,
    category: "Varios",
    status: "Disponible",
    images: ["/images/guitar.jpg", "/images/guitar-2.jpg"],
    description: "Guitarra acústica con acabado natural, incluye funda.",
    condition: "Buen estado, cuerdas nuevas. Detalle del clavijero incluido."
  },
  {
    id: "29",
    title: "Microondas digital",
    price: 50,
    category: "Varios",
    status: "Disponible",
    images: ["/images/microwave.jpg"],
    description: "Microondas de acero inoxidable con funciones programables.",
    condition: "Funciona perfectamente, interior limpio."
  },
  {
    id: "30",
    title: "Aspiradora inalámbrica",
    price: 85,
    category: "Varios",
    status: "Disponible",
    images: ["/images/vacuum.jpg"],
    description: "Aspiradora de mano y piso 2 en 1, sin cables.",
    condition: "Excelente estado, batería dura 30 minutos."
  },
  {
    id: "31",
    title: "Ventilador de torre",
    price: 40,
    category: "Varios",
    status: "Disponible",
    images: ["/images/fan.jpg"],
    description: "Ventilador de torre con control remoto y 3 velocidades.",
    condition: "Como nuevo, muy silencioso."
  },
  {
    id: "32",
    title: "Alfombra decorativa",
    price: 45,
    category: "Varios",
    status: "Disponible",
    images: ["/images/rug.jpg"],
    description: "Alfombra de 2x1.5m con diseño geométrico moderno.",
    condition: "Muy buen estado, colores vibrantes, fácil de limpiar."
  },
  {
    id: "33",
    title: "Plancha a vapor",
    price: 25,
    category: "Varios",
    status: "Disponible",
    images: ["/images/iron.jpg"],
    description: "Plancha con sistema antigoteo y suela antiadherente.",
    condition: "Funciona perfectamente, cable en buen estado."
  }
]

export const categories: Category[] = ["Muebles", "Electrónica", "Ropa", "Varios", ]
