import { ProductGrid } from "@/components/product-grid"
import { Tag } from "lucide-react"
import { siteConfig } from "@/lib/site-config"

export default function GarageSalePage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                {siteConfig.header.title}
              </h1>
              <p className="text-sm text-muted-foreground">
                {siteConfig.header.subtitle}
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <section className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-2">
            Artículos en venta
          </h2>
          <p className="text-muted-foreground">
            Haz clic en cualquier artículo para ver más detalles y consultar disponibilidad
          </p>
        </div>

        <ProductGrid />
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-sm text-muted-foreground space-y-1">
            <p>{siteConfig.footer.text}</p>
            <p>
              {siteConfig.footer.contactText} {siteConfig.footer.phoneNumber}
            </p>
          </div>
        </div>
      </footer>
    </main>
  )
}
