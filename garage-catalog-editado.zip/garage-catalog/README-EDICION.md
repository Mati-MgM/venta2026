# 📝 GUÍA DE EDICIÓN - GARAGE SALE CATALOG

## 🎯 Archivos Principales para Editar

### 1️⃣ **PRODUCTOS** → `lib/products-config.ts`
Aquí editas toda la información de tus productos.

### 2️⃣ **TEXTOS DEL SITIO** → `lib/site-config.ts`
Aquí cambias todos los textos que aparecen en la página.

### 3️⃣ **IMÁGENES** → `public/images/`
Aquí colocas las fotos de tus productos.

---

## 📦 Cómo Agregar/Editar un Producto

### Abre el archivo: `lib/products-config.ts`

Cada producto tiene este formato:

```typescript
{
  id: "1",                              // ⚠️ DEBE SER ÚNICO
  title: "Nombre del producto",         // 📝 El título que verán
  price: 150,                           // 💰 Precio SIN el símbolo $
  category: "Muebles",                  // 📁 Opciones: "Muebles", "Electrónica", "Ropa", "Varios"
  status: "Disponible",                 // ✅ Opciones: "Disponible", "Vendido"
  images: ["/images/foto.jpg"],         // 📸 Ruta de la imagen
  description: "Descripción breve",     // 📄 Texto que aparece en la tarjeta
  condition: "Estado detallado"         // 🔍 Condición del producto
}
```

### ✅ Ejemplo de cómo agregar un producto nuevo:

```typescript
{
  id: "34",
  title: "Bicicleta infantil",
  price: 50,
  category: "Varios",
  status: "Disponible",
  images: ["/images/bici-nino.jpg"],
  description: "Bicicleta para niños de 6-8 años, color azul",
  condition: "Excelente estado, con rueditas de entrenamiento"
}
```

### 🎨 Para agregar MÚLTIPLES IMÁGENES:

```typescript
images: [
  "/images/producto-frente.jpg",
  "/images/producto-lado.jpg",
  "/images/producto-detalle.jpg"
]
```

---

## 🖼️ Cómo Agregar Imágenes

### Opción 1: Imágenes Locales
1. Coloca tu imagen en la carpeta `public/images/`
2. Nombra el archivo (ej: `laptop-nueva.jpg`)
3. En `products-config.ts` usa: `"/images/laptop-nueva.jpg"`

### Opción 2: Imágenes desde Internet
Puedes usar URLs directas:
```typescript
images: ["https://ejemplo.com/mi-imagen.jpg"]
```

---

## 📝 Cómo Editar los Textos del Sitio

### Abre el archivo: `lib/site-config.ts`

Aquí puedes cambiar:

```typescript
export const siteConfig = {
  // Título principal
  header: {
    title: "🏠 Venta de Garage",        // ← Cambia esto
    subtitle: "Todo debe irse"           // ← Y esto
  },
  
  // Textos de los botones
  productCard: {
    viewDetailsButton: "Ver detalles",   // ← Texto del botón
    priceSymbol: "$"                     // ← Símbolo de moneda
  },
  
  // WhatsApp
  contact: {
    whatsappNumber: "59898765432",       // ← TU NÚMERO
  }
}
```

---

## 📱 Configurar WhatsApp

En `lib/site-config.ts`:

```typescript
contact: {
  // Número en formato internacional (sin + ni espacios)
  whatsappNumber: "59898765432",  // Uruguay: 598 + número
  
  // Mensaje automático
  whatsappMessageTemplate: (productTitle: string) => 
    `Hola! Me interesa ${productTitle}. ¿Está disponible?`
}
```

**Ejemplos de formato de números:**
- Uruguay: `59898123456`
- Argentina: `5491112345678`
- España: `34612345678`
- México: `525512345678`

---

## 🎨 Cambiar Colores (Opcional)

En `lib/site-config.ts` al final del archivo:

```typescript
export const theme = {
  colors: {
    primary: "#3b82f6",      // Color principal (azul)
    success: "#10b981",      // Verde para "Disponible"
    danger: "#ef4444",       // Rojo para "Vendido"
  }
}
```

Usa generadores de colores como: [https://colorhunt.co](https://colorhunt.co)

---

## ✏️ Tareas Comunes

### ❌ Marcar un producto como VENDIDO
```typescript
status: "Vendido"  // Cambia de "Disponible" a "Vendido"
```

### 💰 Cambiar el precio
```typescript
price: 75  // Solo el número, sin $
```

### 📝 Editar la descripción
```typescript
description: "Tu nueva descripción aquí"
```

### 🗑️ Eliminar un producto
Simplemente borra TODO el bloque `{ ... }` del producto.

---

## 🚀 Cómo Probar los Cambios

1. Guarda los archivos editados
2. Si tienes el servidor corriendo:
   - Presiona `Ctrl + S` para guardar
   - La página se actualizará automáticamente
3. Si no está corriendo:
   ```bash
   npm run dev
   ```
4. Abre: `http://localhost:3000`

---

## 🆘 Solución de Problemas

### ⚠️ "El sitio no carga"
- Verifica que guardaste los archivos
- Revisa que no falten comas (`,`) entre productos
- Asegúrate que cada `{` tenga su `}`

### 🖼️ "No aparecen las imágenes"
- Verifica que la ruta sea correcta: `"/images/nombre.jpg"`
- Confirma que la imagen esté en `public/images/`
- El nombre debe coincidir EXACTAMENTE (mayúsculas/minúsculas)

### 💬 "WhatsApp no funciona"
- Verifica el número (sin espacios ni símbolos)
- Debe estar en formato internacional
- Ejemplo correcto: `59898765432`

---

## 📋 Checklist Rápido

Antes de publicar, verifica:

- [ ] Todos los productos tienen ID único
- [ ] Las rutas de imágenes son correctas
- [ ] El número de WhatsApp está bien configurado
- [ ] Los precios son correctos
- [ ] Los productos vendidos están marcados como "Vendido"
- [ ] Los textos están sin errores ortográficos
- [ ] Probaste el sitio en tu navegador

---

## 🎯 Estructura de Archivos

```
garage-sale-catalog/
├── lib/
│   ├── products-config.ts    ← 📦 EDITA TUS PRODUCTOS AQUÍ
│   └── site-config.ts        ← 📝 EDITA LOS TEXTOS AQUÍ
├── public/
│   └── images/               ← 🖼️ COLOCA TUS IMÁGENES AQUÍ
│       ├── sofa.jpg
│       ├── tv.jpg
│       └── ...
└── README-EDICION.md         ← 📖 ESTA GUÍA
```

---

## 💡 Consejos Finales

1. **Siempre guarda después de editar** (`Ctrl + S`)
2. **Prueba después de cada cambio importante**
3. **Haz copias de seguridad** de `products-config.ts`
4. **Las imágenes pequeñas cargan más rápido** (máx 500KB por imagen)
5. **Usa nombres descriptivos** para las imágenes (ej: `sofa-gris-grande.jpg`)

---

¿Necesitas más ayuda? Revisa los ejemplos en `products-config.ts` 🚀
