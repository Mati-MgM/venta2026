"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { X, MessageCircle, ChevronLeft, ChevronRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import type { Product } from "@/lib/products-config"
import { siteConfig } from "@/lib/site-config"

interface ProductModalProps {
  product: Product | null
  isOpen: boolean
  onClose: () => void
  whatsappNumber: string
}

export function ProductModal({ product, isOpen, onClose, whatsappNumber }: ProductModalProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  useEffect(() => {
    if (product) {
      setCurrentImageIndex(0)
    }
  }, [product])

  if (!product) return null

  const whatsappMessage = encodeURIComponent(
    siteConfig.contact.whatsappMessageTemplate(product.title)
  )
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`

  const hasMultipleImages = product.images.length > 1

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length)
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setCurrentImageIndex(0)
      onClose()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold pr-8">{product.title}</DialogTitle>
          <button
            onClick={onClose}
            className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
          >
            <X className="h-5 w-5" />
            <span className="sr-only">{siteConfig.productModal.closeButton}</span>
          </button>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Image Gallery */}
          <div className="relative">
            <div className="relative aspect-[4/3] overflow-hidden rounded-lg">
              <Image
                src={product.images[currentImageIndex] || "/placeholder.svg"}
                alt={`${product.title} - Foto ${currentImageIndex + 1}`}
                fill
                className="object-cover"
                sizes="(max-width: 640px) 100vw, 500px"
              />
            </div>

            {/* Navigation Arrows */}
            {hasMultipleImages && (
              <>
                <button
                  onClick={prevImage}
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-foreground/70 hover:bg-foreground/90 text-background rounded-full p-2 transition-colors"
                  aria-label="Foto anterior"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  onClick={nextImage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-foreground/70 hover:bg-foreground/90 text-background rounded-full p-2 transition-colors"
                  aria-label="Foto siguiente"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </>
            )}

            {/* Image Counter */}
            {hasMultipleImages && (
              <div className="absolute bottom-2 right-2 bg-foreground/70 text-background text-sm px-3 py-1 rounded-full">
                {currentImageIndex + 1} / {product.images.length}
              </div>
            )}
          </div>

          {/* Thumbnail Strip */}
          {hasMultipleImages && (
            <div className="flex gap-2 overflow-x-auto pb-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`relative flex-shrink-0 w-16 h-16 rounded-md overflow-hidden border-2 transition-all ${
                    index === currentImageIndex
                      ? "border-primary ring-2 ring-primary/30"
                      : "border-border hover:border-primary/50"
                  }`}
                >
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${product.title} - Miniatura ${index + 1}`}
                    fill
                    className="object-cover"
                    sizes="64px"
                  />
                </button>
              ))}
            </div>
          )}

          <div className="flex items-center justify-between">
            <p className="text-3xl font-bold text-primary">
              {siteConfig.productCard.priceSymbol}{product.price}
            </p>
            <Badge 
              className={`${
                product.status === "Disponible" 
                  ? "bg-success text-success-foreground" 
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {product.status}
            </Badge>
          </div>

          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-foreground">
                {siteConfig.productModal.descriptionTitle}
              </h4>
              <p className="text-muted-foreground">{product.description}</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground">
                {siteConfig.productModal.conditionTitle}
              </h4>
              <p className="text-muted-foreground">{product.condition}</p>
            </div>

            <div>
              <span className="text-sm text-muted-foreground">
                {siteConfig.productModal.categoryLabel} 
              </span>
              <span className="text-sm font-medium">{product.category}</span>
            </div>
          </div>

          {product.status === "Disponible" && (
            <Button 
              asChild 
              className="w-full bg-[#25D366] hover:bg-[#20BD5A] text-white"
              size="lg"
            >
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="mr-2 h-5 w-5" />
                {siteConfig.productModal.contactButton}
              </a>
            </Button>
          )}

          {product.status === "Vendido" && (
            <div className="bg-muted rounded-lg p-4 text-center">
              <p className="text-muted-foreground font-medium">Este artículo ya fue vendido</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
