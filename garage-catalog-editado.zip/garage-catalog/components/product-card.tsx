"use client"

import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import type { Product } from "@/lib/products-config"
import { siteConfig } from "@/lib/site-config"

interface ProductCardProps {
  product: Product
  onClick: () => void
}

export function ProductCard({ product, onClick }: ProductCardProps) {
  return (
    <Card 
      className="group cursor-pointer overflow-hidden border-border/50 transition-all duration-300 hover:shadow-lg hover:border-primary/30"
      onClick={onClick}
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={product.images[0] || "/placeholder.svg"}
          alt={product.title}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
        />
        {product.images.length > 1 && (
          <div className="absolute bottom-2 left-2 bg-foreground/70 text-background text-xs px-2 py-1 rounded-full">
            {product.images.length} fotos
          </div>
        )}
        <Badge 
          className={`absolute top-3 right-3 ${
            product.status === "Disponible" 
              ? "bg-success text-success-foreground" 
              : "bg-muted text-muted-foreground"
          }`}
        >
          {product.status}
        </Badge>
      </div>
      <CardContent className="p-4">
        <h3 className="font-semibold text-foreground line-clamp-1 text-lg">
          {product.title}
        </h3>
        <p className="text-sm text-muted-foreground mt-1">{product.category}</p>
        <p className="text-xl font-bold text-primary mt-2">
          {siteConfig.productCard.priceSymbol}{product.price}
        </p>
      </CardContent>
    </Card>
  )
}
